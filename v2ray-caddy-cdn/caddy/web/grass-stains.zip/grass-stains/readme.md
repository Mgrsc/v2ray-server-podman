## Project Description

* [live example](https://learning-zone.github.io/website-templates/grass_stains/)

![alt text](https://github.com/learning-zone/Website-Templates/blob/master/assets/grass_stains.png "grass_stains")
